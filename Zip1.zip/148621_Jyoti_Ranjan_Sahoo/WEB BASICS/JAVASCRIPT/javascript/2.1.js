	function loopfor()
	{
	var i;
		for(i=0;i<10;i++)
		{
		
		document.write(i + "&nbsp; &nbsp;");
		
		}
		}
		
		function loopwhile()
		{
		var j=1;
	while(j<100)
	{
	document.write(j+ " ");
	j++
	}
		}
		
		function dowhile(){
			var i=0;
			do{
			document.write(i+ " ");
			i++
			}while(i<100)

	}