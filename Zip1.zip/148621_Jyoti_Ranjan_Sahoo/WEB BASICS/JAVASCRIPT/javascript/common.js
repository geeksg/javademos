var msg;
msg="<p><code>The actual script is in external script file called common.js</code></p>";
document.write(msg);
function addNos(headVar,bodyVar)
{
   var cr = headVar+bodyVar;
   return cr;
}
