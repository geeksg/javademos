function validatee()
{
 var amount=document.loan.amt.value;
 var Interest=document.loan.rate.value;
 var years=document.loan.year.value;
 var x=Math.pow(1+Interest,years);
 var month=(amount*x*Interest)/(x-1);
     
	 document.loan.mon.value=round(month);
	 document.loan.total.value=round(month*years);
	 document.loan.interest.value=round((month*years)-amount);
}	 
	 function round(x)
	 {
		return Math.round(x*100)/100;
	 }
