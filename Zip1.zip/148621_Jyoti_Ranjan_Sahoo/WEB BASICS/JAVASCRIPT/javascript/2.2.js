function add()
	{ 
	var p=1000;
	 var n=1;
	 var r=10;
	 var CI;
	 var a=Math.pow(1+r/100,n);
	 CI = p * a-p;
	 document.write("Principal "+p+"rs");
	 document.write("<br>"+"Rate of interest- "+r+"%");
     document.write("<br>"+"Period -"+n+"yr");
     document.write("<br>"+"Compound Interest -"+CI);

	}