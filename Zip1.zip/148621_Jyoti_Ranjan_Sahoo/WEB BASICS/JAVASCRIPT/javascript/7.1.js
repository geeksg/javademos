function validatee()
{  
 newwin=open("","Stock Details");
   var qty=document.product.qty.value;
   var qty1=document.product.qty1.value;
   var qty2=document.product.qty2.value;
   var qty3=document.product.qty3.value;
   
	if(document.product.qty.value =="" && document.product.qty1.value =="" && document.product.qty2.value =="" && document.product.qty3.value =="" )
	{
	 alert("No item selected");
	}
		
	else if(!qty=="")
	{
	 var tot_cal=20*qty;
	 newwin.document.write("<table border='1'><tr><th>Product</th><th>Quantity</th><th>Price</th><th>Total</th></tr><tr><td>Barbie Doll</td><td>"+document.product.qty.value+"</td><td>20</td><td>"+tot_cal+"</td></tr></table>");
	}
	
	else if(!qty1=="")
	{
	 var tot_cal=30*qty1;
	 newwin.document.write("<table border='1'><tr><th>Product</th><th>Quantity</th><th>Price</th><th>Total</th></tr><tr><td>Calculator</td><td>"+document.product.qty1.value+"</td><td>20</td><td>"+tot_cal+"</td></tr></table>");
	}
	else if(!qty2=="")
	{
	 var tot_cal=40*qty2;
	 newwin.document.write("<table border='1'><tr><th>Product</th><th>Quantity</th><th>Price</th><th>Total</th></tr><tr><td>Mobile Phone</td><td>"+document.product.qty2.value+"</td><td>20</td><td>"+tot_cal+"</td></tr></table>");
	}
	else if(!qty3=="")
	{
	 var tot_cal=50*qty3;
	 newwin.document.write("<table border=1><tr><th>Product</th><th>Quantity</th><th>Price</th><th>Total</th></tr><tr><td>LG DVD</td><td>"+document.product.qty3.value+"</td><td>20</td><td>"+tot_cal+"</td></tr></table>");
	}
	
}