var msg
msg="<h1>declared in external .js file</h1>"
function message()
	{
		alert("This alert box was called with the onload event")
	}