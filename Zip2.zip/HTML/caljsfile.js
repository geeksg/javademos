
function calculate()
{
	var qty = document.forms["frm1"].elements["val1"].value
	var cost = document.forms["frm1"].elements["val2"].value
	var r=qty*cost;
	alert("Quantity: "+qty+" PerUnit cost:"+cost+" Total Price"+r);
}

function msg()
{
	alert("The Product cost is not valid");
}