function message()
{
	window.open().alert("Your form has been submitted successfully.");
}