function msg()
{
	if(document.forms["form"]["s1"].checked=false)&&
	if(document.forms["form"]["s2"].checked=false)&&
	if(document.forms["form"]["s3"].checked=false)&&
	if(document.forms["form"]["s4"].checked=false)

alert("select one option.")
return false;
}