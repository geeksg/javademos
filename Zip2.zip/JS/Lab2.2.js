function calc(p,r,n){
var co_in;
co_in=(p*(Math.pow(1+(r/100),n)))-p;
return co_in
}