function msg()
{
var messsage;
message="common.js"
document.write("<p><code>The actual script is in external script file called " +message+"</code></p>");
}

function addNos(headVar,bodyVar){

document.write("The sum of the variables headVar and bodyVar is "+(headVar+bodyVar))
}