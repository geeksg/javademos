function order(){
	var bar=document.forms[0].Barbie.value
	var calc=document.forms[0].Calculator.value
	var mob=document.forms[0].mobi.value
	var lgd=document.forms[0].lg.value
	if(!(bar==""&&calc==""&&mob==""&&lgd=="")){
		if(!(bar=="")){
			
			var qty=document.getElementById('Barbie').value;
			var ttl=20*qty;
			var win=window.open("","NewWindow","toolbar=no,status=no,width=500,height=300,top=300,left=400")
			var barb="<html><head><script src='/../7.html'></script></head><body><center>"
			barb+="<h1 style='text-align:center'>INVOICE</h1>"
			barb+="<form>"
			barb+="<table border=2>"
			barb+="<tr>"
			barb+="<th>PRODUCT</th>"
			barb+="<th>QUANTITY</th>"
			barb+="<th>PRICE</th>"
			barb+="<th>TOTAL</th>"
			barb+="</tr>"
			barb+="<tr>"
			barb+="<td>Barbie Doll</td>"
			barb+="<td><script>document.write("+qty+")</script></td>"
			barb+="<td>20</td>"
			barb+="<td><script>document.write("+ttl+")</script></td>"
			barb+="</tr>"
			barb+="</table>"
			barb+="</form>"
			barb+="</center></body></html>"
			win.document.write(barb)
			
			

		}
		if(!(calc=="")){
			
			var qty=document.getElementById('Calculator').value;
			var ttl=30*qty;
			var win=window.open("","NewWindow","toolbar=no,status=no,width=500,height=300,top=300,left=400")
			var barb="<html><head><script src='/../7.html'></script></head><body><center>"
			barb+="<h1 style='text-align:center'>INVOICE</h1>"
			barb+="<form>"
			barb+="<table border=2>"
			barb+="<tr>"
			barb+="<th>PRODUCT</th>"
			barb+="<th>QUANTITY</th>"
			barb+="<th>PRICE</th>"
			barb+="<th>TOTAL</th>"
			barb+="</tr>"
			barb+="<tr>"
			barb+="<td>Barbie Doll</td>"
			barb+="<td><script>document.write("+qty+")</script></td>"
			barb+="<td>30</td>"
			barb+="<td><script>document.write("+ttl+")</script></td>"
			barb+="</tr>"
			barb+="</table>"
			barb+="</form>"
			barb+="</center></body></html>"
			win.document.write(barb)
			
			

		}
		if(!(mob=="")){
			
			var qty=document.getElementById('mobi').value;
			var ttl=40*qty;
			var win=window.open("","NewWindow","toolbar=no,status=no,width=500,height=300,top=300,left=400")
			var barb="<html><head><script src='/../7.html'></script></head><body><center>"
			barb+="<h1 style='text-align:center'>INVOICE</h1>"
			barb+="<form>"
			barb+="<table border=2>"
			barb+="<tr>"
			barb+="<th>PRODUCT</th>"
			barb+="<th>QUANTITY</th>"
			barb+="<th>PRICE</th>"
			barb+="<th>TOTAL</th>"
			barb+="</tr>"
			barb+="<tr>"
			barb+="<td>Barbie Doll</td>"
			barb+="<td><script>document.write("+qty+")</script></td>"
			barb+="<td>40</td>"
			barb+="<td><script>document.write("+ttl+")</script></td>"
			barb+="</tr>"
			barb+="</table>"
			barb+="</form>"
			barb+="</center></body></html>"
			win.document.write(barb)
			
			

		}
		if(!(lgd=="")){
			
			var qty=document.getElementById('lg').value;
			var ttl=50*qty;
			var win=window.open("","NewWindow","toolbar=no,status=no,width=500,height=300,top=300,left=400")
			var barb="<html><head><script src='/../7.html'></script></head><body><center>"
			barb+="<h1 style='text-align:center'>INVOICE</h1>"
			barb+="<form>"
			barb+="<table border=2>"
			barb+="<tr>"
			barb+="<th>PRODUCT</th>"
			barb+="<th>QUANTITY</th>"
			barb+="<th>PRICE</th>"
			barb+="<th>TOTAL</th>"
			barb+="</tr>"
			barb+="<tr>"
			barb+="<td>Barbie Doll</td>"
			barb+="<td><script>document.write("+qty+")</script></td>"
			barb+="<td>50</td>"
			barb+="<td><script>document.write("+ttl+")</script></td>"
			barb+="</tr>"
			barb+="</table>"
			barb+="</form>"
			barb+="</center></body></html>"
			win.document.write(barb)
			
			

		}
		
	}
	else
		alert("no item selected")
	
		

}
