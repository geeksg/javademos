function sayHello()
{
var msg="Hello World"

document.write("This text is displayed by Calling external function : "+msg);
}