function dclick()
	{
		var winnew =window.open("","employee details","width=500,height=500");
		var ch="";
		ch= document.getElementById("sel").value;
		if(ch == "Chennai")
		{
			c="Chennai";
			s="Tamil nadu";

		}
		else if(ch== "Bangalore")
		{	
			c="Bangalore";
			s="Karnataka";
		}
		else if(ch== "Pune")
		{
			c="Pune";
			s="Maharashtra";
		}
		else if(ch== "Mumbai")
		{
			c="Mumbai";
			s="Maharashtra";
		}
		else if(ch== "select option")
		{
			alert("select the one city");
		}
		

		winnew.document.write("<table align='center'><td colspan='2'><h1 size='50'>Employee details</h1></td><br><tr><td>first name:</td><td>"+document.getElementById("fname").value+"</td></tr>");
		winnew.document.write("<tr><td>last name:</td><td>"+document.getElementById("lname").value+"</td></tr>");
		winnew.document.write("<tr><td>mob no:</td><td>"+document.getElementById("mob").value+"</td></tr>");
		winnew.document.write("<tr><td>Email Id:</td><td>"+document.getElementById("mail").value+"</td></tr>");
		winnew.document.write("<tr><td>DOB:</td><td>"+document.getElementById("bday").value+"</td></tr>");		
		winnew.document.write("<tr><td>City:</td><td>"+c+"</td></tr>");
		winnew.document.write("<tr><td>state:</td><td>"+s+"<tr><td>");
	}
