package com.cg.WebDriver;


import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TuitionEnquiry {
		
		static WebDriver driver;
		public static void main(String[] args) throws InterruptedException 
		{
			//Invocation
			driver = new FirefoxDriver();
			driver.get("file:///C://Users//jyotiras//Desktop/M4%20HTML%20file//Coaching_Class_Enquiry.html");
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			
			//Verifying the title		
			String title = "Online Coaching Class Enquiry Form";
			if(title.equals(driver.getTitle()))
			{
				System.out.println("Title is verified");
			
				//Verifying Text on web page
				String text = "Tuition Enquiry Details Form";
				if(text.equals(driver.findElement(By.xpath("html/body/form/table/tbody/tr[1]/td/h3[2]/i/span/span"))))
				{
					System.out.println("Text is present");
				}
				else
				{
					System.out.println("Text is not present");
				}
			
				driver.findElement(By.id("fname")).sendKeys("");
			driver.findElement(By.id("lname")).click();
			String firstName = "First Name must be filled out";
			Alert alert=driver.switchTo().alert();
			Thread.sleep(1000);
			if(firstName.equals(alert.getText()))
			{
				alert.accept();
				System.out.println("Last name field can not be left blank.");
			}
			else
			{
				System.out.println("First name field is not showing the alert message if left blank");
			}
			driver.findElement(By.id("fname")).click();
			driver.switchTo().alert();
			alert.accept();
				
				Thread.sleep(1500);
				driver.findElement(By.id("fname")).sendKeys("Jyoti Ranjan");	//First name
			
				driver.findElement(By.id("lname")).sendKeys("");
			driver.findElement(By.id("emails")).click();
			String lastName = "Last Name must be filled out";
			alert=driver.switchTo().alert();
			Thread.sleep(1000);
			if(lastName.equals(alert.getText()))
			{
				alert.accept();
				System.out.println("Last name field can not be left blank.");
			}
			else
			{
				System.out.println("Last name field is not showing the alert message if left blank");
			}
			driver.findElement(By.id("lname")).click();
			driver.switchTo().alert();
			alert.accept();
				
				Thread.sleep(1500);
				driver.findElement(By.id("lname")).sendKeys("Sahoo");	//Last name
				driver.findElement(By.id("emails")).sendKeys("abc@xyz.com");	//Email
			
				driver.findElement(By.id("mobile")).sendKeys("");
			driver.findElement(By.id("enqdetails")).click();
			String mobile = "Mobile must be filled out";
			alert=driver.switchTo().alert();
			Thread.sleep(1500);
			if(mobile.equals(alert.getText()))
			{
				System.out.println("Mobile field is showing alert message if left blank");
				alert.accept();
			}
			else
			{
				System.out.println("Mobile field can not be left blank");
			}
			mobile = "Enter 10 digit Mobile number";
			alert=driver.switchTo().alert();
			if(mobile.equals(alert.getText()))
			{
				System.out.println("Mobile field is showing alert message if characters are given");
				alert.accept();
			}
			else
			{
				System.out.println("Mobile field is not showing the alert message if characters are given");
			}
				
				Thread.sleep(1500);
				driver.findElement(By.id("mobile")).sendKeys("8895441223");
				
				//Selecting the drop down boxes
				
				driver.findElement(By.name("D6")).click();
				WebElement tuition=driver.findElement(By.xpath("html/body/form/table/tbody/tr[6]/td[2]/select/option[2]"));
				tuition.click();
				System.out.println(tuition.isSelected());
			
				driver.findElement(By.name("D5")).click();
				WebElement city=driver.findElement(By.xpath("html/body/form/table/tbody/tr[7]/td[2]/select/option[2]"));
				city.click();
				System.out.println(city.isSelected()); 
				
				driver.findElement(By.name("D4")).click();
				WebElement learning=driver.findElement(By.xpath("html/body/form/table/tbody/tr[8]/td[2]/select/option[3]"));
				learning.click();
				System.out.println(learning.isSelected()); 
				
				driver.findElement(By.id("Submit1")).click();
			String enquiry = "Enquiry details must be filled out";
			alert=driver.switchTo().alert();
			Thread.sleep(1000);
			if(enquiry.equals(alert.getText()))
			{
				alert.accept();
				System.out.println("Enquiry field is verified");
			}
			else
			{
				System.out.println("Enquiry field is not showing the alert message if left blank");
			}
				
				Thread.sleep(1500);
				driver.findElement(By.id("enqdetails")).sendKeys("From which date classes will start?");
				Thread.sleep(1500);
				
				//verifying alert message after submitting
				
				driver.findElement(By.id("Submit1")).click();
				Alert alert1 = driver.switchTo().alert();
				String submit = "Thank you for submitting the online coaching Class Enquiry";
				Thread.sleep(1000);
				if(submit.equals(alert1.getText()))
				{
					alert1.accept();
					System.out.println("submit message is verified");
				}
				else
				{
					System.out.println("submit button is not showing the alert message if left blank");
				}
				Thread.sleep(1500);
				
				//verifying text after submission
				
				String text2 = "Our Counselor will contact you soon";
				Thread.sleep(1500);
				
				if(text2.equals(driver.findElement(By.tagName("h3"))))
				{
					System.out.println("Text is same");
				}
				else
				{
					System.out.println("Text is not same");
				}
				Thread.sleep(1500);
				//Closing the browser
				driver.close();
				
			}
			else
			{
				System.out.println("Title is not same");
				driver.close();
			}		

		}
}
