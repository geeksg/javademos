package com.cg.Grid;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;

public class PhantomJSDemo {
	public static void main(String[] args) 
	{
		File file= new File("C:\\Users\\jyotiras\\Desktop\\phantomjs-2.1.1-windows\\bin\\phantomjs.exe");
		System.setProperty("phantomjs.binary.path",file.getAbsolutePath());
		WebDriver driver= new PhantomJSDriver();
		driver.get("http://www.google.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS );
		System.out.println(driver.getTitle());
	}

}
