package com.cg.demos;

//import org.junit.Assert;
import junit.framework.Assert;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AlertExample {
	public static void main(String[] args) {
	//System.setProperty("webdriver.chrome.driver","C:\\Users\\jyotiras\\Desktop\\VnV 11Apr 2018 Denali BLR\\ALL Materials\\Module 4\\Chrome Driver\\chromedriver.exe");	
	//WebDriver driver= new ChromeDriver();
	WebDriver driver= new FirefoxDriver();
	
	driver.get("file:///C://Users//jyotiras//Desktop//VnV%2011Apr%202018%20Denali%20BLR//ALL%20Materials//Module%204//Lesson%205-HTML%20Pages//Lesson%205-HTML%20Pages//AlertExample.html");
	driver.findElement(By.name("txtName")).click();
	driver.findElement(By.name("txtName")).sendKeys("Hi Shilpa");
	driver.findElement(By.name("btnAlert")).click();
	Alert alert = driver.switchTo().alert();
	String a="ThankYou";
			if(a.equals(alert.getText()))
			{
				System.out.println("same text");
			}
			else
			{
				System.out.println("not same");
				//driver.close();
			}
	//boolean b = alert.getText().contains("thank you");
	//alert.accept();
	//System.out.println(b);
	//Assert.assertEquals("ThankYou", alert.getText());
	}
}