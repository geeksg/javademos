package com.cg.demos;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class DemoDemo {

		static WebDriver driver;
		public static void main(String[] args) throws InterruptedException 
		{
			//Invocation
			driver = new FirefoxDriver();
			driver.get("file:///C://Users//jyotiras//Desktop/M4%20HTML%20file//Coaching_Class_Enquiry.html");
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			
			//Verifying the title		
			String title = "Online Coaching Class Enquiry Form";
			if(title.equals(driver.getTitle()))
			{
				System.out.println("Title is verified");
			
				//Verifying Text on web page
				String text = "Tuition Enquiry Details Form";
				if(text.equals(driver.findElement(By.xpath("html/body/form/table/tbody/tr[1]/td/h3[2]/i/span/span"))))
				{
					System.out.println("Text is present");
				}
				else
				{
					System.out.println("Text is not present");
				}
			
				driver.findElement(By.id("fname")).sendKeys("");
			driver.findElement(By.id("lname")).click();
			String firstName = "First Name must be filled out";
			Alert alert=driver.switchTo().alert();
			Thread.sleep(1000);
			if(firstName.equals(alert.getText()))
			{
				alert.accept();
				System.out.println("Last name field can not be left blank.");
			}
			else
			{
				System.out.println("First name field is not showing the alert message if left blank");
			}
			driver.findElement(By.id("fname")).click();
			driver.switchTo().alert();
			alert.accept();
				
				Thread.sleep(1500);
				driver.findElement(By.id("fname")).sendKeys("Jyoti Ranjan");	//First name
			
				driver.findElement(By.id("lname")).sendKeys("");
			driver.findElement(By.id("emails")).click();
			String lastName = "Last Name must be filled out";
			alert=driver.switchTo().alert();
			Thread.sleep(1000);
			if(lastName.equals(alert.getText()))
			{
				alert.accept();
				System.out.println("Last name field can not be left blank.");
			}
			else
			{
				System.out.println("Last name field is not showing the alert message if left blank");
			}
			driver.findElement(By.id("lname")).click();
			driver.switchTo().alert();
			alert.accept();
				
				Thread.sleep(1500);
				driver.findElement(By.id("lname")).sendKeys("Sahoo");	//Last name
				driver.findElement(By.id("emails")).sendKeys("abc@xyz.com");	//Email
			
				driver.findElement(By.id("mobile")).sendKeys("");
			driver.findElement(By.id("enqdetails")).click();
			String mobile = "Mobile must be filled out";
			alert=driver.switchTo().alert();
			Thread.sleep(1500);
			if(mobile.equals(alert.getText()))
			{
				System.out.println("Mobile field is showing alert message if left blank");
				alert.accept();
			}
			else
			{
				System.out.println("Mobile field can not be left blank");
			}
			mobile = "Enter 10 digit Mobile number";
			alert=driver.switchTo().alert();
			if(mobile.equals(alert.getText()))
			{
				System.out.println("Mobile field is showing alert message if characters are given");
				alert.accept();
			}
			else
			{
				System.out.println("Mobile field is not showing the alert message if characters are given");
			}
				
				Thread.sleep(1500);
				driver.findElement(By.id("mobile")).sendKeys("8895441223");
				
				//Selecting the drop down boxes
				
				Select select=new Select(driver.findElement(By.name("D6")));
				select.selectByVisibleText("Spoken English");
				Thread.sleep(1500);
				select=new Select(driver.findElement(By.name("D5")));
				select.selectByVisibleText("Pune");
				Thread.sleep(1500);
				select=new Select(driver.findElement(By.name("D4")));
				select.selectByVisibleText("Class rooom training");
				Thread.sleep(1500);
				
				driver.findElement(By.id("Submit1")).click();
			String enquiry = "Enquiry details must be filled out";
			alert=driver.switchTo().alert();
			Thread.sleep(1000);
			if(enquiry.equals(alert.getText()))
			{
				alert.accept();
				System.out.println("Enquiry field is verified");
			}
			else
			{
				System.out.println("Enquiry field is not showing the alert message if left blank");
			}
				
				Thread.sleep(1500);
				driver.findElement(By.id("enqdetails")).sendKeys("From which date classes will start?");
				Thread.sleep(1500);
				
				//verifying alert message after submitting
				
				driver.findElement(By.id("Submit1")).click();
				Alert alert1 = driver.switchTo().alert();
				String submit = "Thank you for submitting the online coaching Class Enquiry";
				Thread.sleep(1000);
				if(submit.equals(alert1.getText()))
				{
					alert1.accept();
					System.out.println("submit message is verified");
				}
				else
				{
					System.out.println("submit button is not showing the alert message if left blank");
				}
				Thread.sleep(1500);
				
				//verifying text after submission
				
				String text2 = "Our Counselor will contact you soon";
				Thread.sleep(1500);
				
				if(text2.equals(driver.findElement(By.tagName("h3"))))
				{
					System.out.println("Text is same");
				}
				else
				{
					System.out.println("Text is not same");
				}
				Thread.sleep(1500);
				//Closing the browser
				driver.close();
				
			}
			else
			{
				System.out.println("Title is not same");
				driver.close();
			}		

		}

	}



