package com.cg.demos;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

public class Demo2 {
	
		public static void main(String[] args) throws InterruptedException 
		{
			// TODO Auto-generated method stub
			//Setting up Firefox as web Browser
			WebDriver driver=new FirefoxDriver();
			//Opening the given file (URL)
			driver.get("file:///C://Users//jyotiras//Desktop/M4%20HTML%20file//Coaching_Class_Enquiry.html");
			 driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			 String parentWindow = driver.getWindowHandle().toString();
			 driver.manage().window().maximize();
			 Thread.sleep(15000);
			 //Verifying the title of Page
			 String Title=driver.getTitle();
			 if(Title.equals("Online Coaching Class Enquiry Form"))
			 {
				String text= driver.findElement(By.xpath("html/body/form/table/tbody/tr[1]/td/h3[2]/i/span/span")).getText();
				//Verifying the Message
				 Assert.assertEquals("Tuition Enquiry Details Form",text);
				 driver.findElement(By.id("fname")).sendKeys("");
				 driver.findElement(By.id("Submit1")).click();
				 String message1=driver.switchTo().alert().getText();
				 driver.switchTo().alert().accept();
				 System.out.println(message1);
				 //Verifying the first name alert Box
				 driver.switchTo().alert().accept();
				 Assert.assertEquals("First Name must be filled out",message1);
				 Thread.sleep(2000);
				 driver.switchTo().window(parentWindow);
				 driver.findElement(By.id("fname")).sendKeys("Sheron");
				 driver.findElement(By.id("lname")).sendKeys("");
				 driver.findElement(By.id("Submit1")).click();
				 String message2=driver.switchTo().alert().getText();
				 //Verifying the last name alert Box
				 driver.switchTo().alert().accept();
				 System.out.println(message2);
				 driver.switchTo().alert().accept();
				 Assert.assertEquals("Last Name must be filled out",message2);
				 Thread.sleep(2000);
				 driver.switchTo().window(parentWindow);
				 //filling the details
				 driver.findElement(By.id("lname")).sendKeys("Sharma");
				 driver.findElement(By.name("email")).sendKeys("sha@gmail.com");
				 driver.findElement(By.xpath(".//*[@id='mobile']")).sendKeys("ADGHJ");
				 driver.findElement(By.id("Submit1")).click();
				 String message3=driver.switchTo().alert().getText();
				 driver.switchTo().alert().accept();
				 System.out.println(message3);
				 driver.switchTo().alert().accept();
				 Thread.sleep(2000);
				 driver.switchTo().window(parentWindow);
				 driver.findElement(By.xpath(".//*[@id='mobile']")).clear();
				 //verifying phone no alert box
				 driver.findElement(By.xpath(".//*[@id='mobile']")).sendKeys("12233456788999876");
				 driver.findElement(By.id("Submit1")).click();
				 String message4=driver.switchTo().alert().getText();
				 driver.switchTo().alert().accept();
				 System.out.println(message4);
				 driver.switchTo().alert().accept();
				 Thread.sleep(2000);
				 driver.switchTo().window(parentWindow);
				 driver.findElement(By.xpath(".//*[@id='mobile']")).clear();
				 driver.findElement(By.xpath(".//*[@id='mobile']")).sendKeys("9856139984");
				 driver.findElement(By.cssSelector(".auto-style6>select")).click();
				 WebElement Tselected=driver.findElement(By.xpath("html/body/form/table/tbody/tr[6]/td[2]/select/option[2]"));Tselected.click();
				 System.out.println(Tselected.isSelected());
				 driver.findElement(By.name("D5")).click();
				 WebElement Cselected=driver.findElement(By.xpath("html/body/form/table/tbody/tr[7]/td[2]/select/option[2]"));Cselected.click();
				 System.out.println(Cselected.isSelected());
				 driver.findElement(By.xpath("html/body/form/table/tbody/tr[8]/td[2]/select")).click();
				 WebElement Mselected=driver.findElement(By.xpath("html/body/form/table/tbody/tr[8]/td[2]/select/option[3]"));Mselected.click();
				 System.out.println(Mselected.isSelected());
				 driver.findElement(By.cssSelector("#enqdetails")).sendKeys("Give Complete Information");
				 driver.findElement(By.id("Submit1")).click();
				 Thread.sleep(4000);
				 //verifying the alert box for submitting details
				 String message=driver.switchTo().alert().getText();
				 driver.switchTo().alert().accept();
				 Assert.assertEquals("Thank you for submitting the online coaching Class Enquiry",message);
				 String conformation=driver.findElement(By.xpath("html>body>h3")).getText();
				 System.out.println(conformation);
				 driver.close();
				 
			 }
			 else
			 {
				 driver.close();
			 }

		}

	}


