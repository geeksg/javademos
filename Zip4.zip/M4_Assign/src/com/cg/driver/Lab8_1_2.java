package com.cg.driver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;


public class Lab8_1_2 {
	public static void main(String[] args) throws MalformedURLException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\jyotiras\\Desktop\\VnV 11Apr 2018 Denali BLR\\ALL Materials\\Module 4\\Chrome Driver\\chromedriver.exe");
		DesiredCapabilities capability = DesiredCapabilities.chrome();
		capability.setBrowserName("chrome");
		capability.setPlatform(Platform.ANY);
		
		WebDriver driver = new RemoteWebDriver(new URL("http://10.51.16.109:4444/wd/hub"),capability);
		try
		{
			driver.get("https://demo.opencart.com/");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(2000);
			driver.findElement(By.linkText("My Account")).click();
			driver.findElement(By.linkText("Login")).click();
			driver.findElement(By.id("input-email")).sendKeys("hari56@gmail.com");
			driver.findElement(By.name("password")).sendKeys("Hari#123");
			driver.findElement(By.xpath(".//*[@id='content']/div/div[2]/div/form/input")).click();
			Thread.sleep(2000);
			driver.findElement(By.linkText("Components")).click();
			driver.findElement(By.linkText("Monitors (2)")).click();
			Select show = new Select(driver.findElement(By.id("input-limit")));
			show.selectByVisibleText("25");
			driver.findElement(By.xpath(".//*[@id='content']/div[3]/div[1]/div/div[2]/div[2]/button[1]")).click();
			Thread.sleep(1500);
			driver.findElement(By.linkText("Specification")).click();
			driver.findElement(By.xpath(".//*[@id='content']/div[1]/div[2]/div[1]/button[1]")).click();
			Thread.sleep(1500);
			String wishAlert = "Success: You have added Apple Cinema 30\" to your wish list!";
			//String wishAlert = driver.findElement(By.xpath(".//*[@id='product-product']/div[1]")).getText();
			System.out.println(wishAlert);
			Thread.sleep(1000);
			//String expected = Success: You have added Apple Cinema 30" to your wish list!;
			String actual = driver.findElement(By.xpath(".//*[@id='product-product']/div[1]")).getText();
			
			Thread.sleep(1000);
			//Assert.assertEquals(actual, wishAlert);
			//System.out.println("True");
			if(wishAlert.equals(actual))
			{
				System.out.println("True");
			}
			else
			{
				System.out.println("False");
			}
			driver.findElement(By.name("search")).sendKeys("Mobile");
			driver.findElement(By.xpath(".//*[@id='search']/span/button")).click();
			driver.findElement(By.id("description")).click();
			driver.findElement(By.id("button-search")).click();
			driver.findElement(By.linkText("HTC Touch HD")).click();
			Thread.sleep(1000);
			driver.findElement(By.name("quantity")).clear();
			driver.findElement(By.name("quantity")).sendKeys("3");
			driver.findElement(By.id("button-cart")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath(".//*[@id='cart']/button")).click();
			Thread.sleep(1500);
			driver.findElement(By.xpath(".//*[@id='cart']/ul/li[2]/div/p/a[2]/strong")).click();
			Thread.sleep(1500);
			driver.findElement(By.xpath(".//*[@id='content']/div[3]/div[2]/a")).click();
			Thread.sleep(2000);
			driver.findElement(By.linkText("My Account")).click();
			driver.findElement(By.linkText("Logout")).click();
			boolean title = driver.getTitle().contains("Account Logout");
			if(title)
			{
				System.out.println("Account Logout title matches");
			}
			else
			{
				System.out.println("Account Logout title not matches");
			}
			driver.findElement(By.xpath(".//*[@id='content']/div/div/a")).click();
			Thread.sleep(3000);
			driver.close();
		}
		catch(Exception e)
		{
			System.out.println("Hello");
		}
	}

}
