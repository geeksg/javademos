package com.cg.ClassDemo;

public class IntegrationAPIdemo {

	public static void main(String[] args) {
	
}
}
