package com.cg.ClassDemo;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AlertNaukriDemo {
	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver driver=  new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://www.naukri.com/");
		String parentWindow=driver.getWindowHandle();
		
		System.out.println("Parent Window: "+parentWindow);
		
		for (String childWindow : driver.getWindowHandles())
		{
		  if(!childWindow.equals(parentWindow))
		  {
				driver.switchTo().window(childWindow);
				Thread.sleep(3000);
				driver.close();
				Thread.sleep(3000);	
				driver.switchTo().window(parentWindow);
				Thread.sleep(3000);
		  }
		}
		driver.switchTo().window(parentWindow);
		driver.close();
	}
}
