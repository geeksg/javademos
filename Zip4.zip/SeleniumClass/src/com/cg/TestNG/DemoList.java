package com.cg.TestNG;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class DemoList {
	
	WebDriver driver;
	@BeforeClass
	public void bfr()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\jyotiras\\Desktop\\VnV 11Apr 2018 Denali BLR\\ALL Materials\\Module 4\\Chrome Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.javatpoint.com/");
	}
	@Test
	public void NoOfLinks() 
	{
		List<WebElement> elements = driver.findElements(By.tagName("a"));
		String[] text = new String[elements.size()];
		System.out.println("Total Number of Hyperlinks in webpage is: "+elements.size());
		
		int count = 0;
		
		//getting links in the web page
		
		for(WebElement e : elements)
		{
			text[count] = e.getText();
			System.out.println("The hyperlink name is: " +text[count]);
			count++;
		}		
	}
	@AfterClass
	public void afrclass()
	{
		driver.close();
	}
}

	


