package com.cg.TestNG;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



public class DemoTestNG1 {
		@BeforeTest
		public void bfrmtd()
		{
		System.out.println("Executing before method.");
		}
		  @Test(priority=1)
		  public void Login() 
		  {
			  System.out.println("Login to app.");
		  }
		  @Test(priority=2)
		  public void Delete()
		  {
			  System.out.println("Delete from app.");
		  }
		  @AfterTest
		  public void afrmtd()
		  {
			  System.out.println("Executing after method.");
		  }
}

