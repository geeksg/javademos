package com.cg.TestNG;

import org.testng.annotations.Test;

public class DemoTestNG {
  @Test(priority=1)
  public void Login() {
	  System.out.println("Login to app.");
  }
  @Test(priority=2)
  public void Delete(){
	  System.out.println("Delete from app.");
  }
}
