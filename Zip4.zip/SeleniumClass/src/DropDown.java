import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class DropDown {
	public static void main(String[] args) {
	//System.setProperty("webdriver.chrome.driver","C:\\Users\\jyotiras\\Desktop\\VnV 11Apr 2018 Denali BLR\\ALL Materials\\Module 4\\Chrome Driver\\chromedriver.exe");	
	WebDriver driver= new FirefoxDriver();
	
	driver.get("file:///C://Users//jyotiras//Desktop//Dropdown.html");
	Select drpState= new Select(driver.findElement(By.name("City")));
	drpState.selectByVisibleText("Pune");
	//driver.d
	WebElement kancheck = driver.findElement(By.id("a"));
	kancheck.click();
	System.out.println(kancheck.isSelected());
	
	}
}
