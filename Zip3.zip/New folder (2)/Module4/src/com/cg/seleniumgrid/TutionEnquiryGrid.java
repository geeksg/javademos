package com.cg.seleniumgrid;

import java.net.MalformedURLException;
import java.net.URL;

import junit.framework.Assert;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

//import com.gargoylesoftware.htmlunit.javascript.host.URL;

public class TutionEnquiryGrid {
	public String driverPath="C:\\Users\\saravija\\Desktop\\Advanced Selenium Libs\\Selenium Grid\\selenium-server-standalone-2.47.1";
public static void main(String[] args) throws MalformedURLException, InterruptedException {
	
	
	DesiredCapabilities capability=DesiredCapabilities.firefox();
	capability.setBrowserName("firefox");
	capability.setPlatform(Platform.ANY);
	//capability.setVersion("50.5");
	
	WebDriver driver=new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"),capability);
			try{
				driver.get("file://///ntblrfs001/TRNG_BLR$/BANGALORE%20FRESHERS/VnV%2011Apr%202018%20Denali%20BLR/M4%20HTML%20file/Coaching_Class_Enquiry.html");
				driver.manage().window().maximize();
				driver.findElement(By.id("fname")).sendKeys("Saraswathi");
				Thread.sleep(1500); 
				   driver.findElement(By.name("lname")).sendKeys("Vijayan");
				   Thread.sleep(1500); 
				    
			 
				
			}
			finally
			{
				System.out.println("Selenium Grid");
			}
			
			
			


}
}
