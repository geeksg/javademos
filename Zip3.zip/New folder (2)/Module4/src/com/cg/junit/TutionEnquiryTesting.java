package com.cg.junit;

import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class TutionEnquiryTesting {

	
		WebDriver driver;
		
			
			@BeforeClass
			public void beforeClass()
			{
				driver=new FirefoxDriver();
				driver.get("file://///ntblrfs001/TRNG_BLR$/BANGALORE%20FRESHERS/VnV%2011Apr%202018%20Denali%20BLR/M4%20HTML%20file/Coaching_Class_Enquiry.html");
			}
			
			@Test
			public void testAdNewBook() throws InterruptedException 
			{
				
				driver.findElement(By.id("fname")).sendKeys("Saraswathi");
				Thread.sleep(1500); 
				   driver.findElement(By.name("lname")).sendKeys("Vijayan");
				   Thread.sleep(1500); 
			}
			@AfterClass
			public  void afterClass()
			{
				driver.close();
			}
			

		

	}


