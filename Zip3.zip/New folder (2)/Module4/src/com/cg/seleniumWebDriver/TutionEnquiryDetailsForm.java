package com.cg.seleniumWebDriver;


import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TutionEnquiryDetailsForm {//html/body/form/table/tbody/tr[1]/td/h3[2]/i/span/span

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new FirefoxDriver();
		driver.get("file://///ntblrfs001/TRNG_BLR$/BANGALORE%20FRESHERS/VnV%2011Apr%202018%20Denali%20BLR/M4%20HTML%20file/Coaching_Class_Enquiry.html");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); //Implicit Wait
		Assert.assertEquals("Online Coaching Class Enquiry Form",driver.getTitle());
		System.out.println("Title is verified");
		Thread.sleep(1500);
		String txt=driver.findElement(By.xpath("html/body/form/table/tbody/tr[1]/td/h3[2]/i/span/span")).getText();
		boolean txtverify=txt.equals("Tuition Enquiry Details Form");
		if(txtverify)
			System.out.println("Web page having Tuition Enquiry Details Form text");
		else
			System.out.println("Web page not having Tuition Enquiry Details Form text");
		Thread.sleep(1500);
		driver.findElement(By.id("fname")).sendKeys("Saraswathi");
		Thread.sleep(1500); 
		   driver.findElement(By.name("lname")).sendKeys("Vijayan");
		   Thread.sleep(1500); 
		   driver.findElement(By.id("emails")).sendKeys("saraswathi@gmail.com");
		   Thread.sleep(1500); 
		   driver.findElement(By.cssSelector("input[name=mobile]")).sendKeys("8888888888");
		   Thread.sleep(1500); 
		   Select drptuition = new Select(driver.findElement(By.name("D6")));
		   Thread.sleep(1500); 
		   drptuition.selectByValue("senglish");
		   Thread.sleep(1500); 
		   Select drpcity = new Select(driver.findElement(By.name("D5")));
		   Thread.sleep(1500); 
		   drpcity.selectByValue("pune");
		   Thread.sleep(1500); 
		   Select drpModeOfLearn = new Select(driver.findElement(By.name("D4")));
		   Thread.sleep(1500); 
		   drpModeOfLearn.selectByVisibleText("Class rooom training");
		   Thread.sleep(1500); 
		   driver.findElement(By.id("enqdetails")).sendKeys("I want to know whether your coaching is available in chennai location or not.");
		   Thread.sleep(1500); 
		   
			 WebElement tuitionReq=driver.findElement(By.xpath("html/body/form/table/tbody/tr[6]/td[2]/select/option[2]"));
			 if(tuitionReq.isSelected())
				    System.out.println("Spoken English is selcted");
				  /* else
				    	tuitionReq.click();	*/
			 Thread.sleep(1500);
			 
			 WebElement cityPre=driver.findElement(By.xpath("html/body/form/table/tbody/tr[7]/td[2]/select/option[2]"));
			 if(cityPre.isSelected())
				    System.out.println("pune is selcted");
				  /*  else
				    	cityPre.click();	*/ 
			 Thread.sleep(1500);
			 WebElement modeLearn=driver.findElement(By.xpath("html/body/form/table/tbody/tr[8]/td[2]/select/option[3]"));
			 if(modeLearn.isSelected())
				    System.out.println("pune is selcted");
				    else
				    	modeLearn.click();	 
			 Thread.sleep(1500);
			 
		   driver.findElement(By.id("Submit1")).click();
		   Thread.sleep(1500);
		   Alert alert=driver.switchTo().alert();
		   String alertMsg=alert.getText();
		   boolean msgverify=alertMsg.equals("Thank you for submitting the online coaching Class Enquiry");
			if(txtverify)
				System.out.println("alert box displays \"Thank you for submitting the online coaching Class Enquiry\"");
			else
				System.out.println("alert box not displays \"Thank you for submitting the online coaching Class Enquiry\"");
			WebDriverWait wait=new WebDriverWait(driver,10);//Explicit Wait
	        wait.until(ExpectedConditions.alertIsPresent());
			alert.accept();
			
			String finalText=driver.findElement(By.cssSelector("h3")).getText();
			
			boolean finalTextVerify=finalText.equals("Our Counselor will contact you soon.");
			if(finalTextVerify)
				System.out.println("Our Counselor will contact you soon text is present");
			else
				System.out.println("Our Counselor will contact you soon text is not present.");
			driver.close();
			
			
	}
}
