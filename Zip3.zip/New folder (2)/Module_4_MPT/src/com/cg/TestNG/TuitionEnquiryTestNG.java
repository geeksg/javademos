package com.cg.TestNG;

import java.util.concurrent.TimeUnit;

import org.junit.*;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;



public class TuitionEnquiryTestNG {
	WebDriver driver;
	@BeforeClass
	public void launchapp()
	{
		driver=new FirefoxDriver();//Example for polymorphism
		driver.get("file:///C://Users//jyotiras//Desktop/M4%20HTML%20file//Coaching_Class_Enquiry.html");
	    driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}
	@Test
	public void AlertTest()
	{
		driver.findElement(By.id("fname")).sendKeys("Jyoti Ranjan");
		
		driver.findElement(By.name("lname")).sendKeys("Sahoo");
		
		driver.findElement(By.xpath(".//*[@id='emails']")).sendKeys("abc@xyz.com");
		
		driver.findElement(By.cssSelector("input[id=mobile]")).sendKeys("8895441223");
		
		Select tuition= new Select(driver.findElement(By.name("D6")));
		tuition.selectByValue("senglish");
		
		Select city= new Select(driver.findElement(By.xpath("html/body/form/table/tbody/tr[7]/td[2]/select")));
		city.selectByIndex(1);
		
		Select learning= new Select(driver.findElement(By.xpath("html/body/form/table/tbody/tr[8]/td[2]/select")));
		learning.selectByVisibleText("Class rooom training");
		
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[9]/td[2]/textarea")).sendKeys("From which date classes will start?");
		
		driver.findElement(By.id("Submit1")).submit();
		
		Alert alert = driver.switchTo().alert();
		alert.accept();
		
	}
	@AfterClass
	public void closeapp()
	{
		driver.close();
	}

}
